<template>
  <div class="app" id="app">
    <user-view v-if="isRouterAlive"></user-view>
  </div>
</template>

<script>
import UserView from './views/UserView.vue';
export default {
  name: 'App',
  components: {
    UserView,
  },
  provide() {
    return {
      reload: this.reload,
    };
  },
  data() {
    return {
      isRouterAlive: true,
    };
  },
  methods: {
    reload() {
      this.isRouterAlive = false;
      this.$nextTick(function () {
        this.isRouterAlive = true;
      });
    },
  },
};
</script>

<style>
.app {
  height: 100%;
  width: 100%;
}
</style>