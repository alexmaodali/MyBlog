<template>
  <div class="home" id="home">
    <el-container>
      <el-header class="header" height='100px'>
        <h1>
          用户管理系统
        </h1>
      </el-header>
      <el-container>
        <el-aside class="aside" width="400px">
          <el-menu :default-openeds="['1','3']">
            <el-submenu index='1'>
              <template slot="title">
                <i class="el-icon-message">用户管理</i>
              </template>
              <el-menu-item index='1-1'>
                <router-link class="link" to="/usercrud">
                  用户增删改查
                </router-link>
              </el-menu-item>
            </el-submenu>
          </el-menu>
        </el-aside>
        <el-main class="main">
          <router-view :key="$route.fullPath" />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
export default {};
</script>

<style>
.header {
  font-size: 20px;
  background-color: transparent;
}
.aside {
  height: 843px;
  background-color: transparent;
}
.main {
  background-color: transparent;
}

.link {
  text-decoration: none;
  color: inherit;
}
</style>
