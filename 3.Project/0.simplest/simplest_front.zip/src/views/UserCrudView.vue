<template>
  <div class="home" id="home">
    <div>
      <el-row>
        <el-col :span="22" style="text-align: right;">
          <el-button type="primary" @click="newItemEvent">新增用户</el-button>
          <el-button type="primary" @click="conditionFindEvent">条件查询</el-button>
        </el-col>
      </el-row>
    </div>
    <hr>
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="checked" label="选择" width="80"><el-checkbox v-model="checked"></el-checkbox></el-table-column>
      <el-table-column prop="id" label="ID" width="80"><template slot-scope="scope">{{scope.row.id}}</template></el-table-column>
      <el-table-column prop="realName" label="姓名" width="150"><template slot-scope="scope">{{scope.row.realName}}</template></el-table-column>
      <el-table-column prop="username" label="用户名" width="150"><template slot-scope="scope">{{scope.row.username}}</template></el-table-column>
      <el-table-column prop="password" label="密码" width="150"><template slot-scope="scope">{{scope.row.password}}</template></el-table-column>
      <el-table-column prop="sex" label="性别" width="120"><template slot-scope="scope">{{scope.row.sex==1?'男':'女'}}</template></el-table-column>
      <el-table-column prop="age" label="年龄" width="120"><template slot-scope="scope">{{scope.row.age}}</template></el-table-column>
      <el-table-column prop="registerTime" label="注册时间" width="200"><template slot-scope="scope">{{formatRegisterTime(scope.row.registerTime)}}</template></el-table-column>
      <el-table-column label="操作" width="220"><template slot-scope="scope"><el-button type="primary" size="small" @click="changeItem(scope.row.id)">更改</el-button><el-button type="primary" size="small" @click="deleteItem(scope.row.id)">删除</el-button></template></el-table-column>
    </el-table><br><br>

    <el-pagination background layout="total,prev,pager,next,sizes,jumper" :total="totalCnt" @size-change="singlePageSizeChange" @current-change="currentPageChange" @prev-click="prevClick" @next-click="nextClick"></el-pagination>

    <el-dialog title="更改信息" :visible.sync="changeItemDialogVisible">
      <el-form :model="changeItemForm">
        <el-form-item label="用户名" :label-width="formLabelWidth">
          <el-input v-model="changeItemForm.username" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="密码" :label-width="formLabelWidth">
          <el-input v-model="changeItemForm.password" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-input v-model="changeItemForm.realName" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="性别" :label-width="formLabelWidth">
          <el-input v-model="changeItemForm.sex" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="年龄" :label-width="formLabelWidth">
          <el-input v-model="changeItemForm.age" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="changeItemDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitChange">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog title="新增信息" :visible.sync="newItemDialogVisible">
      <el-form :model="newItemInfo">
        <el-form-item label="用户名" :label-width="formLabelWidth">
          <el-input v-model="newItemInfo.username" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="密码" :label-width="formLabelWidth">
          <el-input v-model="newItemInfo.password" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-input v-model="newItemInfo.realName" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="性别" :label-width="formLabelWidth">
          <el-input v-model="newItemInfo.sex" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="年龄" :label-width="formLabelWidth">
          <el-input v-model="newItemInfo.age" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="newItemDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitNewItem">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog title="新增信息" :visible.sync="conditionFindDialogVisible">
      <el-form :model="condition">
        <el-form-item label="用户名" :label-width="formLabelWidth">
          <el-input v-model="condition.username" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-input v-model="condition.realName" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="性别" :label-width="formLabelWidth">
          <el-radio v-model="condition.sex" label="0">女</el-radio>
          <el-radio v-model="condition.sex" label="1">男</el-radio>
        </el-form-item>

        <el-form-item label="年龄" :label-width="formLabelWidth">
          <el-input v-model="condition.ageBegin" autocomplete="off" placeholder="大于多少岁"></el-input>
        </el-form-item>

        <el-form-item label="注册时间" :label-width="formLabelWidth">
          <el-date-picker v-model="picker" type="datetimerange" size="small" format="yyyy 年 MM 月 dd日" value-format="yyyy-MM-dd" start-placeholder="开始日期" end-placeholder="结束日期" :default-time="['12:00:00']"></el-date-picker>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="conditionFindDialogVisible= false">取消</el-button>
        <el-button type="primary" @click="submitConditionFind">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import axios from 'axios';
export default {
  setup() {},
  data() {
    return {
      PAGE_REQ_URL: '/api/user/condition',
      tableData: [],
      formLabelWidth: '120px',
      checked: false,
      ageBegin: 1,
      ageEnd: 1,
      totalCnt: 0,
      pageSize: 10,
      currentPage: 1,
      changeItemForm: {
        id: '',
        username: '',
        password: '',
        realName: '',
        sex: '',
        age: '',
      },
      changeItemDialogVisible: false,
      newItemInfo: {
        username: '',
        password: '',
        realName: '',
        sex: '',
        age: '',
      },
      newItemDialogVisible: false,
      conditionFindDialogVisible: false,
      condition: {
        currentPage: this.currentPage,
        pageSize: this.pageSize,
        username: '',
        realName: '',
        sex: '',
        ageBegin: '',
        ageEnd: 100,
        begin: '',
        end: '',
      },
      picker: '',
    };
  },
  methods: {
    relodeWindow() {
      window.location.reload();
    },
    initTable() {
      axios
        .get(this.PAGE_REQ_URL, {
          params: {
            currentPage: this.currentPage,
            pageSize: this.pageSize,
            username: this.condition.username,
            realName: this.condition.realName,
            sex: this.condition.sex,
            ageBegin: this.condition.ageBegin,
            ageEnd: this.condition.ageEnd,
            begin: this.condition.begin,
            end: this.condition.end,
          },
        })
        .then((response) => {
          this.totalCnt = response.data.data.total;
          this.tableData = response.data.data.result;
        })
        .catch((error) => {
          console.log(error);
        });
    },
    formatRegisterTime(registerTimeArray) {
      const date = new Date(
        registerTimeArray[0], // 年
        registerTimeArray[1] - 1, // 月（JavaScript中的月份是从0开始的）
        registerTimeArray[2], // 日
        registerTimeArray[3], // 时
        registerTimeArray[4], // 分
        registerTimeArray[5], // 秒
      );

      const year = date.getFullYear();
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const day = date.getDate().toString().padStart(2, '0');
      const hours = date.getHours().toString().padStart(2, '0');
      const minutes = date.getMinutes().toString().padStart(2, '0');
      const seconds = date.getSeconds().toString().padStart(2, '0');

      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    },
    singlePageSizeChange(e) {
      this.pageSize = e;
      this.initTable();
    },
    currentPageChange(e) {
      this.currentPage = e;
      this.initTable();
    },
    prevClick() {},
    nextClick() {},
    changeItem(id) {
      this.changeItemForm.id = id;
      this.showDialog();
      axios
        .get(`/api/user/${id}`)
        .then((res) => (this.changeItemForm = res.data.data))
        .catch((err) => console.log(err));
    },
    deleteItem(id) {
      axios
        .delete(`/api/user/${id}`)
        .then((res) => {
          console.log(res);
        })
        .catch((err) => {
          console.log(err);
        });
      this.relodeWindow();
    },
    showDialog() {
      this.changeItemDialogVisible = true;
    },
    hideDialog() {
      this.changeItemDialogVisible = false;
    },
    submitChange() {
      console.log(this.changeItemForm);
      axios
        .put('/api/user', this.changeItemForm, {
          headers: { 'Content-Type': 'application/json' },
        })
        .then((res) => console.log(res))
        .catch((err) => console.log(err));
      this.hideDialog();
      this.relodeWindow();
    },
    showNewItemDialog() {
      this.newItemDialogVisible = true;
    },
    hideNewItemDialog() {
      this.newItemDialogVisible = false;
    },
    newItemEvent() {
      this.showNewItemDialog();
    },
    submitNewItem() {
      axios
        .post('/api/user', this.newItemInfo)
        .then((res) => console.log(res))
        .catch((err) => console.log(err));
      this.hideNewItemDialog();
      this.relodeWindow();
    },
    showConditionFindDialog() {
      this.conditionFindDialogVisible = true;
    },
    hideConditionFindDialog() {
      this.conditionFindDialogVisible = false;
    },
    conditionFindEvent() {
      this.showConditionFindDialog();
    },
    submitConditionFind() {
      this.condition.begin = this.picker[0];
      this.condition.end = this.picker[1];
      axios
        .get(this.PAGE_REQ_URL, {
          params: {
            currentPage: this.currentPage,
            pageSize: this.pageSize,
            username: this.condition.username,
            realName: this.condition.realName,
            sex: this.condition.sex,
            ageBegin: this.condition.ageBegin,
            ageEnd: this.condition.ageEnd,
            begin: this.condition.begin,
            end: this.condition.end,
          },
        })
        .then((response) => {
          this.totalCnt = response.data.data.total;
          this.tableData = response.data.data.result;
        })
        .catch((error) => {
          console.log(error);
        });
      this.hideConditionFindDialog();
    },
  },
  mounted() {
    this.initTable();
  },
};
</script>

<style>
.newUserBtn {
  display: flex;
  justify-content: flex-end;
}
</style>

