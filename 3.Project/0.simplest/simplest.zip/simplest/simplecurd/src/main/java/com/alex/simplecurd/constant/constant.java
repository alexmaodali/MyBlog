package com.alex.simplecurd.constant;

public class constant {
    public static final String DELETE_ERROR = "DELETE_ERROR";
    public static final String INSERT_ERROR = "INSERT_ERROR";
    public static final String GETBYID_ERROR = "GETBYID_ERROR";
    public static final String UPDATE_ERROR = "UPDATE_ERROR";
    public static final String FROZEN_ERROR = "FROZEN_ERROR";
    public static final String COMPLEX_DELETE_ERROR = "COMPLEX_DELETE_ERROR";
}
