package com.alex.simplecurd.mapper;

import com.alex.simplecurd.pojo.User;
import org.apache.ibatis.annotations.*;

import java.time.LocalDate;
import java.util.List;

@Mapper
public interface UserMapper {

    // get all users  status=1(valid|not froze) and deleted=0(not deleted)
    @Select("select  * from cruduser where status=1 and `delete` = 0")
    List<User> getAll();

    //delete by ID -> deleted 0->1
    //@Delete("delete from cruduser where id=#{id}")
    @Update("update cruduser set `delete`=1 where id=#{id}")
    int deleteById(Integer id);

    // insert / create a new user
    @Insert("insert into cruduser(username,password,real_name,sex,age,register_time) values " +
            "(#{username},#{password},#{realName},#{sex},#{age},#{registerTime})")
    int insert(User user);

    // ID 回显
    @Select("select * from cruduser where id=#{id}")
    User getById(Integer id);

    // update user
    @Update("update cruduser set username=#{username},password=#{password},real_name=#{realName}," +
            "sex=#{sex},age=#{age} where id=#{id}")
    int update(User user);

    // frozen user's account (status=0)
    @Update("update cruduser set status=0 where id=#{id}")
    int frozen(Integer id);

    // 条件查询
    List<User> page(String username, String realName, Integer sex,
                    Integer ageBegin, Integer ageEnd, LocalDate begin, LocalDate end);

    int complexDelete(List<Integer> ids);
}





















