package com.alex.simplecurd.service.impl;

import com.alex.simplecurd.dto.PageBean;
import com.alex.simplecurd.mapper.UserMapper;
import com.alex.simplecurd.pojo.User;
import com.alex.simplecurd.service.UserService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> getAll() {
        List<User> userList = userMapper.getAll();
        return userList;
    }

    @Override
    public Boolean deleteById(Integer id) {
        Boolean hasDelte = false;
        if (userMapper.deleteById(id) == 1) {
            hasDelte = true;
        }
        return hasDelte;
    }

    @Override
    public Boolean insert(User user) {
        Boolean hasInsert = false;
        user.setRegisterTime(LocalDateTime.now());
//        defalut value 1 0
//        user.setStatus(1);
//        user.setDelete(0);
        if (userMapper.insert(user) == 1) {
            hasInsert = true;
        }
        return hasInsert;
    }

    @Override
    public User getById(Integer id) {
        User user = userMapper.getById(id);
        return user;
    }

    @Override
    public Boolean update(User user) {
        Boolean hasUpdate = false;
        if (userMapper.update(user) == 1) {
            hasUpdate = true;
        }
        return hasUpdate;
    }

    @Override
    public Boolean frozen(Integer id) {
        Boolean hasFrozen = false;
        if (userMapper.frozen(id) == 1) {
            hasFrozen = true;
        }
        return hasFrozen;
    }

    @Override
    public PageBean page(Integer currentPage, Integer pageSize, String username,
                         String realName, Integer sex, Integer ageBegin, Integer ageEnd, LocalDate begin, LocalDate end) {
        PageHelper.startPage(currentPage, pageSize);
        List<User> userList = userMapper.page(username, realName, sex, ageBegin, ageEnd, begin, end);
        Page<User> p = (Page<User>) userList;
        PageBean pageBean = new PageBean(p.getTotal(), p.getResult());
        return pageBean;
    }

    @Override
    public Boolean complexDelete(List<Integer> ids) {
        Boolean hasDelete = false;
        if (userMapper.complexDelete(ids) >= 1) hasDelete = true;
        return hasDelete;
    }
}





























