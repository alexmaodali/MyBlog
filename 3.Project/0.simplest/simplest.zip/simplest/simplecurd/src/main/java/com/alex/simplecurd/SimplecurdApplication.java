package com.alex.simplecurd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplecurdApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimplecurdApplication.class, args);
    }

}
