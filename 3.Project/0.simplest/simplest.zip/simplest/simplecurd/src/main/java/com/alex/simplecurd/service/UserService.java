package com.alex.simplecurd.service;


import com.alex.simplecurd.dto.PageBean;
import com.alex.simplecurd.pojo.User;

import java.net.InetAddress;
import java.time.LocalDate;
import java.util.List;

public interface UserService {

    // get all users
    List<User> getAll();

    // delete user by id
    Boolean deleteById(Integer id);

    // insert|create a new user
    Boolean insert(User user);

    // ID 回显
    User getById(Integer id);

    // update user
    Boolean update(User user);

    // frozen user's account (status=0)
    Boolean frozen(Integer id);

    // 分页查询
    PageBean page(Integer currentPage, Integer pageSize, String username,
                  String realName, Integer sex, Integer ageBegin, Integer ageEnd, LocalDate begin, LocalDate end);

    Boolean complexDelete(List<Integer> ids);
}




























