package com.alex.simplecurd.controller;

import com.alex.simplecurd.constant.constant;
import com.alex.simplecurd.dto.PageBean;
import com.alex.simplecurd.pojo.User;
import com.alex.simplecurd.service.UserService;
import com.alex.simplecurd.utils.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@RequestMapping("/user")
@RestController
@Api(tags = "用户管理")
public class UserController {
    @Autowired
    private UserService userService;

    // get all users
    // can be replacedby page method
    @GetMapping
    @ApiOperation("获取所有用户信息")
    public Result getAll() {
        log.info("\n\n正在查询所有User");
        List<User> userList = userService.getAll();
        return Result.success(userList);
    }

    // delete user by id -> replaced by complexDelete
//    @DeleteMapping("/{id}")
//    @ApiOperation("传统删除")
//    public Result deleteById(@PathVariable Integer id) {
//        log.info("\n\n当前删除的User ID:{}", id);
//        Boolean hasDelete = userService.deleteById(id);
//        if (hasDelete) {
//            return Result.success();
//        }
//        return Result.error(constant.DELETE_ERROR);
//    }

    // create a new user | <-id(autoInc not required) username passwrod realName sex age
    @PostMapping
    @ApiOperation("插入|新增用户")
    public Result insert(@RequestBody User user) {
        log.info("\n\n新增User:{}", user);
        Boolean hasAdd = userService.insert(user);
        if (hasAdd) {
            return Result.success();
        }
        return Result.error(constant.INSERT_ERROR);
    }

    // id 回显
    @GetMapping("/{id}")
    @ApiOperation("根据ID回显")
    public Result getById(@PathVariable Integer id) {
        log.info("\n\n回显ID:{}", id);
        User user = userService.getById(id);
        return Result.success(user);
    }

    // update user's info put|patch
    @PutMapping
    @ApiOperation("更新用户信息")
    public Result update(@RequestBody User user) {
        log.info("\n\nCurrent Update User : {}", user);
        Boolean hasUpdate = userService.update(user);
        if (hasUpdate) {
            return Result.success();
        }
        return Result.error(constant.UPDATE_ERROR);
    }

    // Frozen user's account (status=0)
    @PatchMapping("/{id}")
    @ApiOperation("冻结用户账户")
    public Result frozen(@PathVariable Integer id) {
        log.info("\n\nCurrent Frozen ID: {}", id);
        Boolean hasFrozen = userService.frozen(id);
        if (hasFrozen) {
            return Result.success();
        }
        return Result.error(constant.FROZEN_ERROR);
    }

    // 分页条件查询
    // 查询条件: username realName sex(1,0)
    // age(ageBegin ageEnd) registerTime(begin end)
    @GetMapping("/condition")
    @ApiOperation("综合查询(包括分页|条件)")
    public Result page(@RequestParam(defaultValue = "1") Integer currentPage,
                       @RequestParam(defaultValue = "10") Integer pageSize,
                       String username, String realName, Integer sex, Integer ageBegin,
                       Integer ageEnd,
                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate begin,
                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate end) {
        log.info("\n\n分页查询 参数:currentPage=>{},pageSize=>{}\nusername=>{}," +
                        "realName=>{}\nsex=>{},ageBegin=>{},ageEnd=>{}\nbegin=>{},end=>{}",
                currentPage, pageSize, username, realName, sex, ageBegin, ageEnd, begin, end);
        PageBean pageBean = userService.page(currentPage, pageSize, username,
                realName, sex, ageBegin, ageEnd, begin, end);
        return Result.success(pageBean);
    }

    // mutiple delete operation | single delete operation
    @DeleteMapping("/{ids}")
    @ApiOperation("逻辑删除(包括多个删除)")
    public Result complexDelete(@PathVariable List<Integer> ids) {
        log.info("DELETE ID:{}", ids);
        Boolean hasDelete = userService.complexDelete(ids);
        if (hasDelete) {
            return Result.success();
        }
        return Result.error(constant.COMPLEX_DELETE_ERROR);
    }
}




























